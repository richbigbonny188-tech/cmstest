<?php
/* --------------------------------------------------------------
   InvalidCouponCodeException.inc.php 2020-01-10
   Gambio GmbH
   http://www.gambio.de
   Copyright (c) 2019 Gambio GmbH
   Released under the GNU General Public License (Version 2)
   [http://www.gnu.org/licenses/gpl-2.0.html]
   --------------------------------------------------------------
*/
declare(strict_types=1);

class InvalidCouponCodeException extends \Exception {}
